# OZHEX Linux x86-64 binary distribution

Compiler runtime, CLI tooling and standard library. Self-host compiler source is excluded.
Install: bash installer/install.sh
