#!/usr/bin/env sh
# Remove only a verified OZHEX-managed installation; preserve unrelated user files.
set -eu
PREFIX=${OZHEX_PREFIX:-"$HOME/.local"}
case "$PREFIX" in /*) ;; *) echo "PREFIX mutlak bir yol olmalı" >&2; exit 1 ;; esac
[ "$PREFIX" != "/" ] || { echo "PREFIX=/ güvenlik nedeniyle reddedildi" >&2; exit 1; }

for directory in "$PREFIX" "$PREFIX/bin" "$PREFIX/share" "$PREFIX/share/ozhex"; do
  [ ! -L "$directory" ] || { echo "kaldırma dizini sembolik bağlantı olamaz: $directory" >&2; exit 1; }
done

RUNTIME="$PREFIX/share/ozhex/runtime"
MARKER="$RUNTIME/.ozhex-install.json"
if [ -e "$RUNTIME" ] || [ -L "$RUNTIME" ]; then
  [ -d "$RUNTIME" ] && [ ! -L "$RUNTIME" ] || { echo "kurulu runtime normal bir dizin değil" >&2; exit 1; }
  [ -f "$MARKER" ] && [ ! -L "$MARKER" ] || { echo "runtime OZHEX sahiplik kaydı taşımıyor; hiçbir dosya silinmedi" >&2; exit 1; }
  python3 - "$MARKER" <<'PY'
import json, pathlib, sys
marker = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
if marker != {"format": 1, "managed_by": "OZHEX"}:
    raise SystemExit("runtime sahiplik kaydı geçersiz; hiçbir dosya silinmedi")
PY
fi

if [ -e "$PREFIX/bin/ozhex" ] || [ -L "$PREFIX/bin/ozhex" ]; then
  [ -f "$PREFIX/bin/ozhex" ] && [ ! -L "$PREFIX/bin/ozhex" ] && [ -f "$RUNTIME/tools/ozhex-cli.py" ] && cmp -s "$PREFIX/bin/ozhex" "$RUNTIME/tools/ozhex-cli.py" || { echo "bin/ozhex OZHEX tarafından yönetilmiyor; hiçbir dosya silinmedi" >&2; exit 1; }
fi
if [ -e "$PREFIX/bin/ozhexpm" ] || [ -L "$PREFIX/bin/ozhexpm" ]; then
  [ -f "$PREFIX/bin/ozhexpm" ] && [ ! -L "$PREFIX/bin/ozhexpm" ] && [ -f "$RUNTIME/tools/ozhexpm" ] && cmp -s "$PREFIX/bin/ozhexpm" "$RUNTIME/tools/ozhexpm" || { echo "bin/ozhexpm OZHEX tarafından yönetilmiyor; hiçbir dosya silinmedi" >&2; exit 1; }
fi

rm -f "$PREFIX/bin/ozhex" "$PREFIX/bin/ozhexpm"
if [ -d "$RUNTIME" ] && [ ! -L "$RUNTIME" ]; then
  rm -rf "$PREFIX/share/ozhex/runtime"
fi
rmdir "$PREFIX/share/ozhex" 2>/dev/null || true
echo "OZHEX araçları kaldırıldı: $PREFIX (kullanıcı ayarları ve projeler korundu)"
