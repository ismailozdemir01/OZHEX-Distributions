#!/usr/bin/env sh
# Install the native compiler and the complete Python-backed CLI toolchain.
set -eu
umask 077

PREFIX=${OZHEX_PREFIX:-"$HOME/.local"}
case "$PREFIX" in /*) ;; *) echo "PREFIX mutlak bir yol olmalı" >&2; exit 1 ;; esac
[ "$PREFIX" != "/" ] || { echo "PREFIX=/ güvenlik nedeniyle reddedildi" >&2; exit 1; }
[ ! -L "$PREFIX" ] || { echo "PREFIX sembolik bağlantı olamaz" >&2; exit 1; }
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SEED="$ROOT/selfhost/seed/ozhexc0-linux-x86_64"
PACKAGE_MANAGER="$ROOT/tools/ozhexpm"
SOURCE_TOOLING="$ROOT/tools/ozhex_tooling.py"
SECURITY_SCANNER="$ROOT/tools/ozhex-safe.js"
CLI_WRAPPER="$ROOT/installer/ozhex-cli.py"
STDLIB="$ROOT/stdlib"
command -v python3 >/dev/null 2>&1 || { echo "python3 gerekli" >&2; exit 1; }
python3 -c 'import sys; sys.version_info >= (3, 11) or sys.exit("OZHEX CLI Python 3.11+ gerektirir")'
for source in "$SEED" "$PACKAGE_MANAGER" "$SOURCE_TOOLING" "$SECURITY_SCANNER" "$CLI_WRAPPER"; do
  [ -f "$source" ] && [ ! -L "$source" ] || { echo "gerekli normal kaynak dosyası bulunamadı: $source" >&2; exit 1; }
done
[ -d "$STDLIB" ] && [ ! -L "$STDLIB" ] || { echo "standart kütüphane dizini bulunamadı" >&2; exit 1; }

python3 - "$SEED" <<'PY'
import pathlib, sys
data = pathlib.Path(sys.argv[1]).read_bytes()
if len(data) < 64 or data[:4] != b"\x7fELF" or data[4:7] != bytes((2, 1, 1)) or int.from_bytes(data[18:20], "little") != 62:
    raise SystemExit("seed ikilisi geçerli ELF64 x86-64 değil")
PY

mkdir -p "$PREFIX"
[ -d "$PREFIX" ] && [ ! -L "$PREFIX" ] || { echo "PREFIX normal bir dizin olmalı" >&2; exit 1; }
PREFIX=$(CDPATH= cd -- "$PREFIX" && pwd -P)
mkdir -p "$PREFIX/bin" "$PREFIX/share"
for directory in "$PREFIX" "$PREFIX/bin" "$PREFIX/share"; do
  [ ! -L "$directory" ] || { echo "kurulum dizini sembolik bağlantı olamaz: $directory" >&2; exit 1; }
done
STAGE=$(mktemp -d "$PREFIX/.ozhex-install.XXXXXX")
TOKEN=$(basename "$STAGE")
KEY_TMP=""
RUNTIME="$PREFIX/share/ozhex/runtime"
RUNTIME_BACKUP="$PREFIX/share/ozhex/.runtime.previous.$TOKEN"
OLD_OZHEX="$PREFIX/bin/.ozhex.previous.$TOKEN"
OLD_PM="$PREFIX/bin/.ozhexpm.previous.$TOKEN"
HAD_RUNTIME=0
HAD_OZHEX=0
HAD_PM=0
NEW_RUNTIME=0
NEW_OZHEX=0
NEW_PM=0
COMMITTED=0
cleanup() {
  rm -rf "$STAGE"
  rm -f "$PREFIX/bin/.ozhex.new.$TOKEN" "$PREFIX/bin/.ozhexpm.new.$TOKEN"
  [ -z "$KEY_TMP" ] || rm -f "$KEY_TMP"
  if [ "$COMMITTED" -eq 0 ]; then
    [ "$NEW_OZHEX" -eq 0 ] || rm -f "$PREFIX/bin/ozhex"
    [ "$NEW_PM" -eq 0 ] || rm -f "$PREFIX/bin/ozhexpm"
    [ "$NEW_RUNTIME" -eq 0 ] || rm -rf "$RUNTIME"
    if [ "$HAD_OZHEX" -eq 1 ] && { [ -e "$OLD_OZHEX" ] || [ -L "$OLD_OZHEX" ]; }; then mv "$OLD_OZHEX" "$PREFIX/bin/ozhex"; fi
    if [ "$HAD_PM" -eq 1 ] && { [ -e "$OLD_PM" ] || [ -L "$OLD_PM" ]; }; then mv "$OLD_PM" "$PREFIX/bin/ozhexpm"; fi
    if [ "$HAD_RUNTIME" -eq 1 ] && [ -d "$RUNTIME_BACKUP" ]; then mv "$RUNTIME_BACKUP" "$RUNTIME"; fi
  else
    rm -rf "$RUNTIME_BACKUP" "$OLD_OZHEX" "$OLD_PM"
  fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

mkdir -p "$STAGE/bin" "$STAGE/share/ozhex/runtime/tools"
if [ -n "${OZHEX_PUBLIC_KEY_FILE:-}" ]; then
  [ -f "$OZHEX_PUBLIC_KEY_FILE" ] && [ ! -L "$OZHEX_PUBLIC_KEY_FILE" ] || { echo "OZHEX_PUBLIC_KEY_FILE güvenli bir normal dosya olmalı" >&2; exit 1; }
  mkdir -p "$STAGE/trust"
  cp "$OZHEX_PUBLIC_KEY_FILE" "$STAGE/trust/ozhex.pub"
fi
cp "$SEED" "$STAGE/share/ozhex/runtime/ozhexc0"
cp "$PACKAGE_MANAGER" "$STAGE/share/ozhex/runtime/tools/ozhexpm"
cp "$SOURCE_TOOLING" "$STAGE/share/ozhex/runtime/tools/ozhex_tooling.py"
cp "$SECURITY_SCANNER" "$STAGE/share/ozhex/runtime/tools/ozhex-safe.js"
cp "$PACKAGE_MANAGER" "$STAGE/bin/ozhexpm"
cp "$CLI_WRAPPER" "$STAGE/bin/ozhex"
cp "$CLI_WRAPPER" "$STAGE/share/ozhex/runtime/tools/ozhex-cli.py"
printf '%s\n' '{"format":1,"managed_by":"OZHEX"}' > "$STAGE/share/ozhex/runtime/.ozhex-install.json"
cp -R "$STDLIB" "$STAGE/share/ozhex/runtime/stdlib"
chmod 0755 "$STAGE/share/ozhex/runtime/ozhexc0" "$STAGE/bin/ozhex" "$STAGE/bin/ozhexpm"
python3 - "$STAGE/share/ozhex/runtime/tools/ozhexpm" "$STAGE/share/ozhex/runtime/tools/ozhex_tooling.py" "$STAGE/bin/ozhex" <<'PY'
import ast, pathlib, sys
for value in sys.argv[1:]:
    ast.parse(pathlib.Path(value).read_text(encoding="utf-8"))
PY
"$STAGE/bin/ozhex" --version >/dev/null

mkdir -p "$PREFIX/share/ozhex"
[ ! -L "$PREFIX/share/ozhex" ] || { echo "OZHEX share dizini sembolik bağlantı olamaz" >&2; exit 1; }
if [ -e "$RUNTIME" ] || [ -L "$RUNTIME" ]; then
  [ -d "$RUNTIME" ] && [ ! -L "$RUNTIME" ] || { echo "kurulu runtime yolu normal bir dizin değil" >&2; exit 1; }
  [ -f "$RUNTIME/.ozhex-install.json" ] && [ ! -L "$RUNTIME/.ozhex-install.json" ] || { echo "mevcut runtime OZHEX tarafından yönetildiğini kanıtlamıyor; üzerine yazılmayacak" >&2; exit 1; }
  python3 - "$RUNTIME/.ozhex-install.json" <<'PY'
import json, pathlib, sys
marker = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
if marker != {"format": 1, "managed_by": "OZHEX"}:
    raise SystemExit("mevcut runtime kurulum sahiplik kaydı geçersiz")
PY
fi
if [ -e "$PREFIX/bin/ozhex" ] || [ -L "$PREFIX/bin/ozhex" ]; then
  [ -f "$PREFIX/bin/ozhex" ] && [ ! -L "$PREFIX/bin/ozhex" ] && [ -f "$RUNTIME/tools/ozhex-cli.py" ] && cmp -s "$PREFIX/bin/ozhex" "$RUNTIME/tools/ozhex-cli.py" || { echo "mevcut bin/ozhex OZHEX tarafından yönetilmiyor; üzerine yazılmayacak" >&2; exit 1; }
fi
if [ -e "$PREFIX/bin/ozhexpm" ] || [ -L "$PREFIX/bin/ozhexpm" ]; then
  [ -f "$PREFIX/bin/ozhexpm" ] && [ ! -L "$PREFIX/bin/ozhexpm" ] && [ -f "$RUNTIME/tools/ozhexpm" ] && cmp -s "$PREFIX/bin/ozhexpm" "$RUNTIME/tools/ozhexpm" || { echo "mevcut bin/ozhexpm OZHEX tarafından yönetilmiyor; üzerine yazılmayacak" >&2; exit 1; }
fi
if [ -e "$RUNTIME" ] || [ -L "$RUNTIME" ]; then
  mv "$RUNTIME" "$RUNTIME_BACKUP"
  HAD_RUNTIME=1
fi
if [ -e "$PREFIX/bin/ozhex" ] || [ -L "$PREFIX/bin/ozhex" ]; then
  mv "$PREFIX/bin/ozhex" "$OLD_OZHEX"
  HAD_OZHEX=1
fi
if [ -e "$PREFIX/bin/ozhexpm" ] || [ -L "$PREFIX/bin/ozhexpm" ]; then
  mv "$PREFIX/bin/ozhexpm" "$OLD_PM"
  HAD_PM=1
fi
NEW_RUNTIME=1
mv "$STAGE/share/ozhex/runtime" "$RUNTIME"
mv "$STAGE/bin/ozhex" "$PREFIX/bin/.ozhex.new.$TOKEN"
NEW_OZHEX=1
mv "$PREFIX/bin/.ozhex.new.$TOKEN" "$PREFIX/bin/ozhex"
mv "$STAGE/bin/ozhexpm" "$PREFIX/bin/.ozhexpm.new.$TOKEN"
NEW_PM=1
mv "$PREFIX/bin/.ozhexpm.new.$TOKEN" "$PREFIX/bin/ozhexpm"
"$PREFIX/bin/ozhex" --version >/dev/null || { echo "kurulu derleyici sağlık denetimini geçemedi" >&2; exit 1; }
if [ -f "$STAGE/trust/ozhex.pub" ]; then
  if [ -L "$HOME/.ozhex" ]; then
    echo "Uyarı: kullanıcı güven dizini sembolik bağlantı; mevcut güven ayarı korunuyor." >&2
  elif [ -e "$HOME/.ozhex/ozhex.pub" ] || [ -L "$HOME/.ozhex/ozhex.pub" ]; then
    if [ -f "$HOME/.ozhex/ozhex.pub" ] && [ ! -L "$HOME/.ozhex/ozhex.pub" ] && cmp -s "$HOME/.ozhex/ozhex.pub" "$STAGE/trust/ozhex.pub"; then
      echo "Mevcut OZHEX yayın anahtarı zaten eşleşiyor."
    else
      echo "Uyarı: mevcut kullanıcı yayın anahtarı farklı veya güvenli değil; üzerine yazılmadı." >&2
    fi
  elif mkdir -p "$HOME/.ozhex" && [ ! -L "$HOME/.ozhex" ]; then
    KEY_TMP=$(mktemp "$HOME/.ozhex/.ozhex.pub.tmp.XXXXXX") || KEY_TMP=""
    if [ -n "$KEY_TMP" ] && cp "$STAGE/trust/ozhex.pub" "$KEY_TMP" && chmod 0644 "$KEY_TMP" && mv "$KEY_TMP" "$HOME/.ozhex/ozhex.pub"; then
      KEY_TMP=""
    else
      echo "Uyarı: yayın anahtarı güven dizinine kurulamadı; manuel olarak sağlayın." >&2
      [ -z "$KEY_TMP" ] || rm -f "$KEY_TMP"
      KEY_TMP=""
    fi
  else
    echo "Uyarı: kullanıcı güven dizini oluşturulamadı; yayın anahtarını manuel sağlayın." >&2
  fi
else
  echo "Not: yayın anahtarı kurulmadı; imzalı güncelleyici için anahtarı bağımsız güvenilir kanaldan sağlayın." >&2
fi

COMMITTED=1
rm -rf "$RUNTIME_BACKUP" "$OLD_OZHEX" "$OLD_PM"
trap - EXIT HUP INT TERM
cleanup
echo "OZHEX kuruldu: $PREFIX/bin/ozhex, $PREFIX/bin/ozhexpm"
