#!/usr/bin/env python3
# Keep this shebang LF-terminated; .gitattributes enforces Unix line endings.
"""Installed OZHEX command dispatcher for the native compiler and real tooling."""
from __future__ import annotations

import subprocess
import sys
import tempfile
import shutil
import os
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parent
if (APP_ROOT / "share" / "ozhex" / "runtime").is_dir():
    RUNTIME = APP_ROOT / "share" / "ozhex" / "runtime"
else:
    PREFIX = APP_ROOT.parent
    RUNTIME = PREFIX / "share" / "ozhex" / "runtime"
NATIVE = RUNTIME / "ozhexc0"
TOOLS = RUNTIME / "tools"
PYTHON = sys.executable


def run(command: list[str], environment: dict[str, str] | None = None) -> int:
    try:
        return subprocess.run(command, cwd=Path.cwd(), env=environment, check=False).returncode
    except OSError as exc:
        print(f"ozhex: could not start command: {exc}", file=sys.stderr)
        return 2


def run_security_scanner(arguments: list[str]) -> int:
    node = shutil.which("node")
    scanner = RUNTIME / "tools" / "ozhex-safe.js"
    if not node:
        print("ozhex security: Node.js is required for the integrated heuristic scanner", file=sys.stderr)
        return 2
    if not scanner.is_file() or scanner.is_symlink():
        print("ozhex security: installed scanner source is missing or unsafe", file=sys.stderr)
        return 2
    return run([node, str(scanner), *arguments])


def run_native_compiler(arguments: list[str]) -> int:
    if not NATIVE.is_file() or NATIVE.is_symlink():
        print(f"ozhex: installed native compiler is missing: {NATIVE}", file=sys.stderr)
        return 2
    target = "x86_64-linux"
    for target_index, target_argument in enumerate(arguments[:-1]):
        if target_argument == "--target":
            target = arguments[target_index + 1]
            break
    environment = os.environ.copy()
    environment["OZHEX_TARGET"] = target
    environment["OZHEX_STDLIB_PATH"] = str(RUNTIME / "stdlib")
    source_index = None
    source_path = None
    for index, value in enumerate(arguments):
        candidate = Path(value).expanduser()
        if candidate.suffix == ".ozhex" and candidate.is_file():
            source_index = index
            source_path = candidate
            break
    if source_index is not None and source_path is not None:
        try:
            source_text = source_path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            print(f"ozhex: cannot read source file: {exc}", file=sys.stderr)
            return 2
        if "içe_aktar" in source_text or "ice_aktar" in source_text:
            tooling = TOOLS / "ozhex_tooling.py"
            if not tooling.is_file() or tooling.is_symlink():
                print("ozhex: installed module expansion tooling is missing or unsafe", file=sys.stderr)
                return 2
            try:
                with tempfile.TemporaryDirectory(prefix="ozhex-modules-") as directory:
                    expanded = Path(directory) / source_path.name
                    result = run([PYTHON, str(tooling), "expand", str(source_path), "-o", str(expanded), "--target", target], environment)
                    if result != 0:
                        return result
                    expanded_arguments = list(arguments)
                    expanded_arguments[source_index] = str(expanded)
                    return run([str(NATIVE), *expanded_arguments], environment)
            except OSError as exc:
                print(f"ozhex: module expansion failed: {exc}", file=sys.stderr)
                return 2
    if arguments in (["--version"], ["-v"]):
        try:
            version = subprocess.run(
                [str(NATIVE), *arguments],
                cwd=Path.cwd(),
                env=environment,
                check=False,
                capture_output=True,
                text=True,
                timeout=15,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            print(f"ozhex: could not query native compiler version: {exc}", file=sys.stderr)
            return 2
        if version.returncode == 0:
            sys.stdout.write(version.stdout)
            sys.stderr.write(version.stderr)
            return 0
        if version.returncode == 2 and version.stderr.startswith("kullanim: ozhexc0 "):
            print("OZHEX self-host compiler 0.6.0")
            return 0
        sys.stdout.write(version.stdout)
        sys.stderr.write(version.stderr)
        return version.returncode
    return run([str(NATIVE), *arguments], environment)


def main() -> int:
    if sys.version_info < (3, 11):
        print("ozhex: Python 3.11+ is required for the installed CLI", file=sys.stderr)
        return 2
    arguments = sys.argv[1:]
    if arguments and arguments[0] in {"security", "güvenlik"}:
        return run_security_scanner(arguments[1:])
    if arguments and arguments[0] in {"pm", "paket", "package"}:
        manager = TOOLS / "ozhexpm"
        if not manager.is_file() or manager.is_symlink():
            print("ozhex: installed package manager is missing", file=sys.stderr)
            return 2
        return run([PYTHON, str(manager), *arguments[1:]])
    if arguments and arguments[0] in {"fmt", "doc", "test"}:
        tooling = TOOLS / "ozhex_tooling.py"
        if not tooling.is_file() or tooling.is_symlink():
            print("ozhex: installed source tooling is missing", file=sys.stderr)
            return 2
        return run([PYTHON, str(tooling), arguments[0], *arguments[1:]])
    return run_native_compiler(arguments)


if __name__ == "__main__":
    raise SystemExit(main())
