#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const MAX_SOURCE_BYTES=8*1024*1024, MAX_TOTAL_BYTES=64*1024*1024, MAX_SOURCE_FILES=4096, MAX_DIRECTORY_DEPTH=64;
const SKIP_DIRS=new Set(['.git','.ozhex','.venv','.cache','.idea','.vscode','.ozhex-build','.ozhex-workspaces','.studio-workspaces','node_modules','target','build','dist']);
const meta = {
 'OZH-S001':['ERROR','Tehlikeli süreç/dinamik çalıştırma çağrısı adayı.','Çağrı hedefini doğrula; mümkünse sabit izin listesi ve güvenli API kullan.'],
 'OZH-S002':['ERROR','Ham bellek veya riskli dize API çağrısı adayı.','Sınırları doğrulanan API ve açık sahiplik kuralları kullan.'],
 'OZH-S003':['ERROR','İndeks erişimi adayı; sınırların doğrulandığı kanıtlanmadı.','Erişimden önce alt ve üst sınırları doğrula.'],
 'OZH-S004':['ERROR','Başlatıcısız türü açık değişken bildirimi adayı.','Değişkeni bildirim sırasında başlat veya tüm kontrol yollarında atandığını doğrula.'],
 'OZH-S005':['ERROR','Tür/güven sınırını atlatma adayı (::).','Güven sınırında girdiyi doğrula ve tür değişmezlerini koru.'],
 'OZH-S006':['WARNING','Fonksiyon içi kontrol akışı karmaşıklık eşiği aşıldı.','Kontrol akışını küçük işlevlere ayır.'],
 'OZH-S007':['WARNING','Sabit sıfıra bölme/mod alma adayı.','Böleni kullanımdan önce doğrula.']
};
function mask(s) {
 const a=s.split(''); let q='',esc=false,line=false,block=false;
 for(let i=0;i<s.length;i++){const c=s[i],n=s[i+1];
  if(line){if(c==='\n')line=false;else a[i]=' ';continue;}
  if(block){if(c==='*'&&n==='/'){a[i]=a[i+1]=' ';i++;block=false;}else if(c!=='\n')a[i]=' ';continue;}
  if(q){if(c!=='\n')a[i]=' ';if(esc)esc=false;else if(c==='\\')esc=true;else if(c===q)q='';continue;}
  if(c==='/'&&n==='/'){a[i]=a[i+1]=' ';i++;line=true;continue;}
  if(c==='/'&&n==='*'){a[i]=a[i+1]=' ';i++;block=true;continue;}
  if(c==='"'||c==="'"){q=c;a[i]=' ';}
 }
 return a.join('');
}
function safeRead(p){
 if(!Number.isInteger(fs.constants.O_NOFOLLOW))throw new Error('bu platform O_NOFOLLOW sağlamıyor; güvenli kaynak açma garanti edilemiyor');
 const flags=fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW;
 const fd=fs.openSync(p,flags);
 try{
  const st=fs.fstatSync(fd);
  if(!st.isFile())throw new Error('normal dosya olmayan kaynak reddedildi: '+p);
  if(st.size>MAX_SOURCE_BYTES)throw new Error('kaynak dosya 8 MiB sınırını aşıyor: '+p);
  const buffer=Buffer.alloc(st.size);let offset=0;
  while(offset<buffer.length){
   const count=fs.readSync(fd,buffer,offset,buffer.length-offset,null);
   if(count===0)throw new Error('kaynak dosya tarama sırasında kısaldı: '+p);
   offset+=count;
  }
  const extra=Buffer.alloc(1);
  if(fs.readSync(fd,extra,0,1,null)!==0)throw new Error('kaynak dosya tarama sırasında büyüdü: '+p);
  const source=buffer.toString('utf8');
  if(!Buffer.from(source,'utf8').equals(buffer))throw new Error('kaynak dosya geçerli UTF-8 değil: '+p);
  return source;
 }finally{fs.closeSync(fd);}
}
function files(p,depth=0,state={count:0}){
 if(depth>MAX_DIRECTORY_DEPTH)throw new Error('kaynak dizin derinliği 64 sınırını aşıyor: '+p);
 const st=fs.lstatSync(p);
 if(st.isSymbolicLink())throw new Error('sembolik bağlantı kaynak yolu reddedildi: '+p);
 if(st.isFile()){
  if(!/\.ozhex$/iu.test(p))return [];
  if(++state.count>MAX_SOURCE_FILES)throw new Error('tarama dosya sayısı 4096 sınırını aşıyor');
  return [p];
 }
 if(!st.isDirectory())return [];
 const out=[];
 for(const e of fs.readdirSync(p,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en'))){
  if(e.isDirectory()&&SKIP_DIRS.has(e.name))continue;
  const child=path.join(p,e.name);
  if(e.isSymbolicLink())throw new Error('kaynak ağacında sembolik bağlantı reddedildi: '+child);
  if(e.isDirectory())out.push(...files(child,depth+1,state));
  else if(e.isFile()&&/\.ozhex$/iu.test(e.name)){
   if(++state.count>MAX_SOURCE_FILES)throw new Error('tarama dosya sayısı 4096 sınırını aşıyor');
   out.push(child);
  }
 }
 return out;
}
function scan(file,src){
 const s=mask(src),out=[];
 const add=(i,len,rule)=>{const pre=src.slice(0,i);out.push({file,offset:i,line:(pre.match(/\n/g)||[]).length+1,column:i-pre.lastIndexOf('\n'),length:Math.max(1,len),rule,severity:meta[rule][0],message:meta[rule][1],recommendation:meta[rule][2]});};
 function match(re,rule,filter){re.lastIndex=0;let m;while((m=re.exec(s))){if(!filter||filter(m))add(m.index,m[0].trim().length,rule);}}
 const direct=m=>{const b=s.slice(Math.max(0,m.index-80),m.index);return !/\bfonksiyon\s+$/u.test(b)&&!/[.>\-]\s*$/u.test(b);};
 match(/(?<![\p{L}\p{N}_])(?:system|exec|execl|execv|execvp|execve|execle|execlp|execvpe|fork|vfork|spawn|posix_spawn|popen|eval|unsafe|dlopen|dlsym|CreateProcess|ShellExecute|WinExec|LoadLibrary)(?![\p{L}\p{N}_])\s*\(/gu,'OZH-S001',direct);
 match(/(?<![\p{L}\p{N}_])(?:memcpy|memmove|memccpy|bcopy|memset|free|realloc|calloc|malloc|strcpy|strncpy|strcat|strncat|strdup|strndup|sprintf|vsprintf|gets)(?![\p{L}\p{N}_])\s*\(/gu,'OZH-S002',direct);
 match(/(?:(?<![\p{L}\p{N}_])[\p{L}_][\p{L}\p{N}_]*|\)|\]|\})\s*\[/gu,'OZH-S003');
 match(/\bdeğişken\s+([\p{L}_][\p{L}\p{N}_]*)\s*:\s*[\p{L}_][\p{L}\p{N}_]*\s*;/gu,'OZH-S004',m=>{
  // Ignore a declaration if its first later occurrence is a simple assignment target.
  // This is lexical heuristics, not scope-aware definite-assignment analysis.
  const name=m[1], escaped=name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  // Unicode-aware identifier boundaries are needed for Turkish and other non-ASCII names.
  const re=new RegExp('(?<![\\p{L}\\p{N}_])'+escaped+'(?![\\p{L}\\p{N}_])','gu');
  re.lastIndex=m.index+m[0].length; const use=re.exec(s); if(!use)return true;
  let j=use.index+use[0].length; while(j<s.length&&/\s/u.test(s[j]))j++;
  // Only a plain assignment can initialize; compound assignments and increments read first.
  if(s[j]==='='&&s[j+1]!=='='&&s[j+1]!=='>'){
    let end=s.indexOf(';',j+1); if(end<0)end=s.length;
    const rhs=s.slice(j+1,end);
    const rhsRe=new RegExp('(?<![\\p{L}\\p{N}_])'+escaped+'(?![\\p{L}\\p{N}_])','u');
    if(!rhsRe.test(rhs))return false;
  }
  return true;
 });
 match(/::/gu,'OZH-S005');
 match(/(?:\/|%)\s*(?:(?:[+-]\s*)?0+(?:\.0+)?(?![\p{L}\p{N}_])|\(\s*(?:[+-]\s*)?0+(?:\.0+)?\s*\))/gu,'OZH-S007');
 const fp=/\bfonksiyon\s+[\p{L}_][\p{L}\p{N}_]*\s*\([^)]*\)[^{]*\{/gu;let f;
 while((f=fp.exec(s))){const st=s.indexOf('{',f.index)+1;let d=1,e=st;for(;e<s.length&&d;e++){if(s[e]==='{')d++;else if(s[e]==='}')d--;}const body=s.slice(st,Math.max(st,e-1));const re=/\b(?:eğer|için|iken)\b|&&|\|\|/gu;let m,n=0;while((m=re.exec(body)))if(++n===13){add(st+m.index,m[0].length,'OZH-S006');break;}fp.lastIndex=Math.max(fp.lastIndex,e);}
 return out.sort((a,b)=>a.offset-b.offset);
}
function main(args){
 let json=false,strict=false,targets=[];
 for(const a of args){
  if(a==='--json')json=true;
  else if(a==='--strict')strict=true;
  else if(a==='--list-rules'){
   for(const [id,m] of Object.entries(meta))console.log(id+' ['+m[0]+'] '+m[1]+'\n  Öneri: '+m[2]);
   return 0;
  }else if(a==='--help'||a==='-h'){
   console.log('Kullanım: ozhex güvenlik [--json] [--strict] <dosya.ozhex|dizin> [...]\n       ozhex güvenlik --list-rules\nNot: sezgisel statik taramadır; güvenlik kanıtı veya derleyici doğrulaması değildir.');
   return 0;
  }else if(a.startsWith('-')){console.error('Bilinmeyen seçenek: '+a);return 2;}
  else targets.push(a);
 }
 if(!targets.length){console.error('Kullanım: ozhex güvenlik [--json] [--strict] <dosya.ozhex|dizin> [...]');return 2;}
 let all=[],seen=new Set(),scanned=0,totalBytes=0;
 try{
  for(const t of targets){
   const resolved=path.resolve(t);
   if(!fs.existsSync(resolved))throw new Error('yol bulunamadı: '+t);
   const rootStat=fs.lstatSync(resolved);
   if(rootStat.isSymbolicLink())throw new Error('sembolik bağlantı tarama kökü reddedildi: '+resolved);
   const found=files(fs.realpathSync(resolved));
   if(found.length>MAX_SOURCE_FILES)throw new Error('tarama dosya sayısı 4096 sınırını aşıyor');
   for(const f of found){
    const canonical=path.resolve(f);
    if(seen.has(canonical))continue;
    seen.add(canonical);scanned++;
    if(scanned>MAX_SOURCE_FILES)throw new Error('tarama dosya sayısı 4096 sınırını aşıyor');
    const source=safeRead(canonical);totalBytes+=Buffer.byteLength(source,'utf8');
    if(totalBytes>MAX_TOTAL_BYTES)throw new Error('toplam kaynak boyutu 64 MiB sınırını aşıyor');
    all.push(...scan(path.relative(process.cwd(),canonical),source));
   }
  }
 }catch(e){console.error('ozhex güvenlik: '+e.message);return e.message.startsWith('yol bulunamadı: ')?2:1;}
 if(scanned===0){console.error('ozhex güvenlik: taranacak .ozhex dosyası bulunamadı. Temiz sonuç üretilmedi.');return 2;}
 if(json)console.log(JSON.stringify(all,null,2));
 else if(!all.length)console.log('OZHEX-SAFE: '+scanned+' dosya tarandı; aday bulgu bulunmadı. Bu, programın güvenli olduğunu kanıtlamaz.');
 else{
  for(const d of all)console.log(d.file+':'+d.line+':'+d.column+': '+d.severity+' '+d.rule+': '+d.message+'\n  Öneri: '+d.recommendation);
  const errors=all.filter(d=>d.severity==='ERROR').length;
  console.log('\nOZHEX-SAFE: '+scanned+' dosya, '+all.length+' bulgu ('+errors+' hata, '+(all.length-errors)+' uyarı). Sezgisel taramadır; yanlış pozitif/negatif mümkündür.');
 }
 return all.some(d=>d.severity==='ERROR'||(strict&&d.severity==='WARNING'))?1:0;
}
process.exitCode=main(process.argv.slice(2));
