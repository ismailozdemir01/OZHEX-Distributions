#!/usr/bin/env python3
"""Source-preserving formatter and API documentation generator for OZHEX."""
from __future__ import annotations

import argparse
import os
import re
import stat
import sys
import tempfile
import tomllib
import unittest
from pathlib import Path, PurePosixPath

MULTI_OPERATORS = (
    ">>=", "<<=", "->", "==", "!=", "<=", ">=", "&&", "||",
    "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<", ">>",
    "++", "--",
)
SINGLE_OPERATORS = set("+-*/%=<>!&|^~?")
PUNCTUATION = set("{}()[];,:.")

class ToolingError(Exception):
    pass


def tokenize(source: str) -> list[tuple[str, str]]:
    tokens: list[tuple[str, str]] = []
    index = 0
    length = len(source)
    while index < length:
        char = source[index]
        if char.isspace():
            index += 1
            continue
        if source.startswith("//", index):
            end = source.find("\n", index)
            if end < 0:
                end = length
            tokens.append(("comment", source[index:end]))
            index = end
            continue
        if source.startswith("/*", index):
            end = source.find("*/", index + 2)
            if end < 0:
                raise ToolingError(f"unterminated block comment at character {index}")
            tokens.append(("comment", source[index:end + 2]))
            index = end + 2
            continue
        if char in {'"', "'"}:
            quote = char
            start = index
            index += 1
            while index < length:
                if source[index] == "\\":
                    index += 2
                    continue
                if source[index] == quote:
                    index += 1
                    break
                if source[index] == "\n" and quote == '"':
                    raise ToolingError(f"newline inside string literal at character {start}")
                index += 1
            else:
                raise ToolingError(f"unterminated string/character literal at character {start}")
            if index > length:
                raise ToolingError(f"unterminated escape sequence at character {start}")
            tokens.append(("literal", source[start:index]))
            continue
        if char.isalpha() or char == "_":
            start = index
            index += 1
            while index < length and (source[index].isalnum() or source[index] == "_"):
                index += 1
            tokens.append(("word", source[start:index]))
            continue
        if char.isdigit():
            start = index
            index += 1
            if source[start:index] == "0" and index < length and source[index] in "xX":
                index += 1
                while index < length and (source[index].isdigit() or source[index].lower() in "abcdef"):
                    index += 1
            else:
                while index < length and source[index].isdigit():
                    index += 1
                if index + 1 < length and source[index] == "." and source[index + 1].isdigit():
                    index += 1
                    while index < length and source[index].isdigit():
                        index += 1
            tokens.append(("number", source[start:index]))
            continue
        operator = next((item for item in MULTI_OPERATORS if source.startswith(item, index)), None)
        if operator:
            tokens.append(("operator", operator))
            index += len(operator)
            continue
        if char in SINGLE_OPERATORS:
            tokens.append(("operator", char))
            index += 1
            continue
        if char in PUNCTUATION:
            tokens.append(("punctuation", char))
            index += 1
            continue
        raise ToolingError(f"unsupported source character {char!r} at character {index}")
    return tokens


def format_source(source: str, indent_width: int = 4) -> str:
    tokens = tokenize(source)
    lines: list[str] = []
    current = ""
    indent = 0
    previous: tuple[str, str] | None = None
    continuation_words = {"değilse", "yoksa", "else", "catch", "finally"}

    def flush() -> None:
        nonlocal current
        value = current.rstrip()
        if value:
            lines.append(" " * (indent * indent_width) + value)
        current = ""

    def space() -> None:
        nonlocal current
        if current and not current.endswith(" "):
            current += " "

    for position, token in enumerate(tokens):
        kind, value = token
        next_token = tokens[position + 1] if position + 1 < len(tokens) else None
        if kind == "comment":
            if current:
                space()
                current += value
                flush()
            else:
                current = value
                flush()
            previous = token
            continue
        if value == "{":
            space()
            current += "{"
            flush()
            indent += 1
        elif value == "}":
            flush()
            indent = max(0, indent - 1)
            current = "}"
            if next_token and next_token[0] == "word" and next_token[1] in continuation_words:
                current += " "
            elif next_token and next_token[1] in {";", ",", ")", "]", "."}:
                pass
            else:
                flush()
        elif value == ";":
            current = current.rstrip() + ";"
            flush()
        elif value == ",":
            current = current.rstrip() + ", "
        elif value == ":":
            current = current.rstrip() + ": "
        elif value == ".":
            current = current.rstrip() + "."
        elif value == "(":
            if previous and previous[0] == "word" and previous[1] in {"eğer", "iken", "için", "switch"}:
                space()
            current += "("
        elif value == ")":
            current = current.rstrip() + ")"
        elif value == "[":
            current += "["
        elif value == "]":
            current = current.rstrip() + "]"
        elif kind == "operator":
            unary = value in {"+", "-", "!", "~", "&", "*"} and (
                previous is None
                or previous[1] in {"(", "[", "{", ",", ":", ";", "=", "->"}
                or previous[0] == "operator"
            )
            if unary:
                if previous and previous[1] in {"=", "->"}:
                    space()
                current += value
            else:
                space()
                current += value
                current += " "
        else:
            if current and not current.endswith((" ", ".", "(", "[", "!")):
                space()
            current += value
        previous = token
    flush()
    formatted = "\n".join(lines) + ("\n" if lines else "")
    if tokenize(formatted) != tokens:
        raise ToolingError("formatter refused a rewrite that would change the OZHEX token stream")
    return formatted


def atomic_write(path: Path, content: bytes, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ToolingError(f"refusing to replace symbolic link: {path}")
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    except BaseException:
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass
        raise


DECLARATION = re.compile(r"^\s*(fonksiyon|yapi|enum|sabit)\s+([^\s(:{]+)")


def documentation(source_path: Path, source: str) -> str:
    lines = source.splitlines()
    entries: list[tuple[str, str, str]] = []
    pending: list[str] = []
    index = 0
    while index < len(lines):
        stripped = lines[index].strip()
        if stripped.startswith("///"):
            pending.append(stripped[3:].strip())
            index += 1
            continue
        match = DECLARATION.match(lines[index])
        if match:
            kind, name = match.groups()
            signature = lines[index].strip()
            cursor = index + 1
            while "{" not in signature and cursor < len(lines) and cursor - index < 32:
                following = lines[cursor].strip()
                signature += " " + following
                cursor += 1
                if "{" in following or following.endswith(";"):
                    break
            signature = signature.split("{", 1)[0].strip().rstrip(";")
            description = " ".join(pending) if pending else "Açıklama eklenmemiş."
            entries.append((kind, name, description + "\n\nİmza:\n\n    " + signature))
            pending.clear()
            index = max(index + 1, cursor)
            continue
        if stripped and not stripped.startswith("//"):
            pending.clear()
        index += 1
    output = [
        f"# {source_path.name} API",
        "",
        f"Kaynak: {source_path.name}",
        "",
        f"Toplam API bildirimi: {len(entries)}",
        "",
        "## İçindekiler",
        "",
    ]
    for kind, name, _ in entries:
        output.append(f"- [{name}](#{name.lower().replace('_', '-')}) — {kind}")
    output.extend(("", "## Bildirimler", ""))
    for kind, name, description in entries:
        output.extend((f"### {name}", "", f"Tür: {kind}", "", description, ""))
    return "\n".join(output).rstrip() + "\n"


def input_file_path(value: str) -> Path:
    raw = Path(value).expanduser()
    if raw.name in {"", ".", ".."}:
        raise ToolingError("source path must name a file")
    return raw.parent.resolve() / raw.name


def output_file_path(value: str) -> Path:
    raw = Path(value).expanduser()
    if raw.name in {"", ".", ".."}:
        raise ToolingError("output path must name a file")
    return raw.parent.resolve() / raw.name


IMPORT_DIRECTIVE = re.compile(r'^\s*(?:içe_aktar|ice_aktar)\s+"([^"\n]+)"\s*;\s*(?://.*)?$')


def module_project_root(source: Path) -> Path:
    for candidate in (source.parent, *source.parent.parents):
        # A source checkout is a project root even when it has no package manifest.
        # This permits trusted in-repository modules (for example lsp/src -> selfhost/)
        # while keeping temporary/user projects bounded to their own directory.
        if (candidate / "ozhex.toml").is_file() or (candidate / ".git").exists():
            return candidate
    return source.parent


def resolve_import(source: Path, specification: str, project_root: Path, stdlib_root: Path) -> Path:
    raw = specification.strip()
    if not raw or "\\" in raw or any(ord(char) < 32 or ord(char) == 127 for char in raw):
        raise ToolingError(f"invalid module import path: {specification!r}")
    if raw.startswith("stdlib/"):
        raw = raw[len("stdlib/"):]
    path = PurePosixPath(raw)
    raw_parts = raw.split("/")
    if path.is_absolute() or any(part in {"", "."} for part in raw_parts):
        raise ToolingError(f"module import path is not canonical: {specification!r}")
    relative = Path(*path.parts)
    if relative.suffix == "":
        relative = relative.with_suffix(".ozhex")

    if ".." in raw_parts:
        root = project_root.resolve(strict=True)
        current = source.parent.resolve(strict=True)
        if not current.is_relative_to(root):
            raise ToolingError("source module is outside its project root")
        for part in relative.parts:
            current = current.parent if part == ".." else current / part
            if current.is_symlink():
                raise ToolingError(f"module path contains a symbolic link: {current}")
            if not current.resolve(strict=False).is_relative_to(root):
                raise ToolingError(f"module import path escapes its project root: {specification!r}")
        if current.is_file():
            return current.resolve(strict=True)
        raise ToolingError(f"module not found: {specification!r}")

    for base in (source.parent, stdlib_root):
        current = base.resolve(strict=True)
        for part in relative.parts:
            current = current / part
            if current.is_symlink():
                raise ToolingError(f"module path contains a symbolic link: {current}")
        if current.is_file():
            return current.resolve(strict=True)
    if len(path.parts) == 1 and re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", path.parts[0]):
        package_manifest = project_root / ".ozhex" / "packages" / path.parts[0] / "ozhex.toml"
        package_store = project_root / ".ozhex" / "packages"
        if (project_root / ".ozhex").is_symlink() or package_store.is_symlink():
            raise ToolingError("installed package store contains a symbolic link")
        if package_manifest.is_file() and not package_manifest.is_symlink():
            package_root = package_manifest.parent
            if package_root.is_symlink():
                raise ToolingError("installed package path contains a symbolic link")
            try:
                package = tomllib.loads(package_manifest.read_text(encoding="utf-8")).get("package", {})
                entry = package.get("entry")
                package_name = package.get("name")
                package_version = package.get("version")
            except (OSError, UnicodeError, tomllib.TOMLDecodeError, AttributeError) as exc:
                raise ToolingError(f"cannot read installed package manifest: {exc}") from exc
            if package_name != path.parts[0] or not isinstance(package_version, str):
                raise ToolingError(f"installed package identity does not match its import name: {path.parts[0]}")
            if not isinstance(entry, str):
                raise ToolingError(f"installed package {path.parts[0]} has no valid entry")
            entry_path = PurePosixPath(entry)
            if entry_path.is_absolute() or any(part in {"", ".", ".."} for part in entry.split("/")):
                raise ToolingError(f"installed package {path.parts[0]} has an unsafe entry path")
            current = package_root
            for part in entry_path.parts:
                current = current / part
                if current.is_symlink():
                    raise ToolingError(f"installed package entry contains a symbolic link: {current}")
            if not current.is_file():
                raise ToolingError(f"installed package entry is missing: {current}")
            return current.resolve(strict=True)

    raise ToolingError(f"module not found: {specification!r}")


def expand_imports(source_path: Path, stdlib_root: Path | None = None, target: str | None = None) -> str:
    if source_path.is_symlink() or not source_path.is_file():
        raise ToolingError(f"source must be a normal file: {source_path}")
    project_root = module_project_root(source_path)
    target = target or os.environ.get("OZHEX_TARGET", "x86_64-linux")
    if stdlib_root is None:
        configured = os.environ.get("OZHEX_STDLIB_PATH", "").strip()
        stdlib_root = Path(configured).expanduser() if configured else Path(__file__).resolve().parents[1] / "stdlib"
    if not stdlib_root.is_dir() or stdlib_root.is_symlink():
        raise ToolingError(f"standard library root is missing or unsafe: {stdlib_root}")
    stdlib_root = stdlib_root.resolve(strict=True)
    visited: set[Path] = set()
    active: list[Path] = []
    total_bytes = 0

    def visit(path: Path) -> str:
        nonlocal total_bytes
        resolved = path.resolve(strict=True)
        if resolved in active:
            cycle = " -> ".join(item.name for item in active + [resolved])
            raise ToolingError(f"module import cycle: {cycle}")
        if resolved in visited:
            return ""
        if len(visited) >= 256 or len(active) >= 64:
            raise ToolingError("module graph exceeds the configured depth/count limit")
        if resolved.is_symlink() or not resolved.is_file():
            raise ToolingError(f"module is not a normal source file: {resolved}")
        try:
            text = resolved.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            raise ToolingError(f"cannot read module {resolved}: {exc}") from exc
        required_target = next(
            (
                match.group(1)
                for line in text.splitlines()[:8]
                if (match := re.fullmatch(r"\s*// OZHEX-TARGET:\s*(\S+)\s*", line))
            ),
            None,
        )
        if required_target and target != required_target:
            raise ToolingError(
                f"{resolved.name} requires target {required_target}; requested target is {target}"
            )
        total_bytes += len(text.encode("utf-8"))
        if total_bytes > 16 * 1024 * 1024:
            raise ToolingError("expanded module source exceeds 16 MiB")
        active.append(resolved)
        output: list[str] = []
        for line in text.splitlines():
            match = IMPORT_DIRECTIVE.fullmatch(line)
            if match:
                imported = resolve_import(resolved, match.group(1), project_root, stdlib_root)
                expanded = visit(imported)
                if expanded:
                    output.append(expanded)
            else:
                output.append(line)
        active.pop()
        visited.add(resolved)
        return "// OZHEX module: " + resolved.name + "\n" + "\n".join(output) + "\n"

    return visit(source_path.resolve(strict=True))


def command_expand(args: argparse.Namespace) -> int:
    source = input_file_path(args.source)
    output = output_file_path(args.output)
    if output == source:
        raise ToolingError("expanded source output cannot overwrite its input")
    expanded = expand_imports(source, target=args.target)
    atomic_write(output, expanded.encode("utf-8"), 0o600)
    print(str(output))
    return 0


def command_fmt(args: argparse.Namespace) -> int:
    source_path = input_file_path(args.source)
    if not source_path.is_file() or source_path.is_symlink():
        raise ToolingError(f"source must be a regular file: {source_path}")
    original = source_path.read_text(encoding="utf-8")
    formatted = format_source(original, args.indent)
    if args.check:
        if formatted != original:
            print(f"ozhex fmt: formatting required: {source_path}", file=sys.stderr)
            return 1
        print(f"ozhex fmt: clean: {source_path}")
        return 0
    if args.write:
        mode = stat.S_IMODE(source_path.stat().st_mode)
        atomic_write(source_path, formatted.encode("utf-8"), mode)
        print(f"formatted: {source_path}")
        return 0
    sys.stdout.write(formatted)
    return 0


def command_doc(args: argparse.Namespace) -> int:
    source_path = input_file_path(args.source)
    if not source_path.is_file() or source_path.is_symlink():
        raise ToolingError(f"source must be a regular file: {source_path}")
    source = source_path.read_text(encoding="utf-8")
    output = documentation(source_path, source)
    if args.stdout:
        sys.stdout.write(output)
        return 0
    destination = output_file_path(args.output) if args.output else output_file_path(str(Path.cwd() / "docs" / "api" / f"{source_path.stem}.md"))
    if destination == source_path:
        raise ToolingError("documentation output cannot overwrite the source file")
    atomic_write(destination, output.encode("utf-8"), 0o644)
    print(f"documentation: {destination}")
    return 0


def command_test(args: argparse.Namespace) -> int:
    raw = Path(args.directory).expanduser()
    start = raw.parent.resolve() / raw.name
    if start.is_symlink() or not start.is_dir():
        raise ToolingError(f"test directory must be a normal directory: {start}")
    loader = unittest.TestLoader()
    try:
        suite = loader.discover(str(start), pattern=args.pattern)
    except (ImportError, OSError) as exc:
        raise ToolingError(f"test discovery failed: {exc}") from exc
    count = suite.countTestCases()
    if count == 0:
        raise ToolingError(f"no tests discovered in {start}")
    result = unittest.TextTestRunner(verbosity=args.verbosity).run(suite)
    return 0 if result.wasSuccessful() else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ozhex-tooling")
    sub = parser.add_subparsers(dest="command", required=True)
    fmt = sub.add_parser("fmt", help="format an OZHEX source file")
    fmt.add_argument("source")
    fmt.add_argument("--write", action="store_true")
    fmt.add_argument("--check", action="store_true")
    fmt.add_argument("--indent", type=int, default=4)
    fmt.set_defaults(handler=command_fmt)
    doc = sub.add_parser("doc", help="generate API Markdown from source declarations")
    doc.add_argument("source")
    doc.add_argument("-o", "--output")
    doc.add_argument("--stdout", action="store_true")
    doc.set_defaults(handler=command_doc)
    test = sub.add_parser("test", help="discover and run real unittest cases")
    test.add_argument("directory", nargs="?", default=str(Path.cwd() / "tests"))
    test.add_argument("--pattern", default="test*.py")
    test.add_argument("-v", "--verbosity", type=int, choices=(0, 1, 2), default=2)
    test.set_defaults(handler=command_test)
    expand = sub.add_parser("expand", help="expand explicit source module imports")
    expand.add_argument("source")
    expand.add_argument("-o", "--output", required=True)
    expand.add_argument("--target", default="x86_64-linux")
    expand.set_defaults(handler=command_expand)
    return parser


def main() -> int:
    try:
        args = build_parser().parse_args()
        if args.command == "fmt" and (args.indent < 1 or args.indent > 8 or (args.write and args.check)):
            raise ToolingError("indent must be 1..8 and --write/--check are mutually exclusive")
        return args.handler(args)
    except (ToolingError, OSError, UnicodeError) as exc:
        print(f"ozhex tooling: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())


