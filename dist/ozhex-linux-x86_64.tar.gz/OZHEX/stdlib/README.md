# OZHEX Standard Library — v0.3

v0.3 standard library surface is built from compiler/runtime intrinsics and source modules.

## Core

### yaz(...)

Standard output is provided by the compiler/runtime intrinsic.

~~~ozhex
fonksiyon ana() -> int {
    yaz("Merhaba, OZHEX!");
    yaz(42);
    dön 0;
}
~~~

The intrinsic accepts the currently supported scalar/string values and routes output through the native runtime ABI.

## Source modules and imports

The public CLI expands explicit source imports before invoking the native compiler. Import directives must occupy their own source line:

~~~ozhex
içe_aktar "net/socket.ozhex";
~~~

Resolution order:
1. Relative to the importing source file.
2. The standard library root (repository stdlib/ or installed runtime/stdlib).
3. An installed package by name from the project's .ozhex/packages/<name>/ozhex.toml entry.

Imports are recursively expanded in dependency-first order. Duplicate modules are included once. Cycles, parent traversal, symbolic links, more than 256 modules, nesting deeper than 64 and expanded source larger than 16 MiB are rejected. Use the tools/ozhex CLI or installed ozhex wrapper; direct invocation of the raw native compiler does not perform source import expansion.

The current import layer is a flat source-inclusion model: it does not yet provide module namespaces, aliases, visibility control or per-module symbol isolation.

## Network socket module

stdlib/net/socket.ozhex exposes Linux x86-64 TCP primitives:
- TCP socket creation and close.
- Loopback bind/listen/accept.
- IPv4 literal connect (DNS resolution is not included).
- Bound-port lookup for ephemeral loopback listeners.
- Read, write and retrying write-all operations.
- Close-on-exec socket and accepted descriptors.
- SIGPIPE-safe writes using MSG_NOSIGNAL.
- SO_REUSEADDR and socket timeouts.

These are low-level blocking socket operations. TLS, DNS, async I/O and cross-platform socket backends are not provided by this module yet.

## Remaining standard-library scope

- core source module and target-independent runtime contract.
- string/array/collection APIs and ownership semantics.
- filesystem and process APIs with a stable cross-platform contract.
- DNS/TLS, async I/O, threads and synchronization.
- cryptography, serialization and database drivers.


## Filesystem module

Import the Linux x86-64 file API with:

~~~ozhex
içe_aktar "fs/file.ozhex";
~~~

The module provides regular-file no-follow open, read/write, bounded read-all (16 MiB), size/stat, path existence/type checks, unlink, mkdir, rename, fsync and same-filesystem atomic file replacement. Atomic writes take a caller-provided temporary path, destination and parent-directory path; the caller must keep the temporary and destination in the same directory. Data is fsynced before rename and the containing directory is fsynced after rename. If directory fsync fails, the destination is already published but crash durability is uncertain. Errors are returned as negative Linux errno values. Parent-directory symlink traversal is not sandboxed; callers must keep untrusted paths inside an application-controlled directory.

This module is Linux x86-64 specific. Windows and macOS filesystem backends and a capability-based sandboxed path API remain open.
